import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Food extends Actor {
    private GreenfootSound eatSound;
    public Food() {
        eatSound = new GreenfootSound("eat.wav");
    }
    
    public void act() 
    {
        if (isTouching(SnakeHead.class)) {
            eatSound.play();
        }
    }
}
