import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class SnakeHead here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SnakeHead extends Actor
{
    private final int kanan = 0;
    private final int bawah = 90;
    private final int kiri = 180;
    private final int atas = 270;
    
    private final int SPEED = 15;
    private int counter = 0;
    private int foodEaten = 0;
    
    public SnakeHead()
    {
        setRotation(Greenfoot.getRandomNumber(4)*90);
    }
    /**
     * Act - do whatever the SnakeHead wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void moveAround()
    {
        counter++;
        if(counter == SPEED){
            getWorld().addObject(new Body(foodEaten*SPEED), getX(), getY());
            move(15);
            counter = 0;
        }
        if(Greenfoot.isKeyDown("up"))
            setRotation(atas);
        {
           if(Greenfoot.isKeyDown("down"))
            setRotation(bawah); 
        }
        {
            if(Greenfoot.isKeyDown("left"))
            setRotation(kiri);
        }
        {
            if(Greenfoot.isKeyDown("right"))
            setRotation(kanan);
        }
        

    }
    private boolean facingEdge(){
        switch(getRotation()){
            case kanan: return getX()==getWorld().getWidth()-1;
            case bawah: return getX()==getWorld().getHeight()-1;
            case kiri: return getX()==0;
            case atas: return getX()==0;
            
        }
        return false;
    }
    public void act(){
        moveAround();
        if(isTouching(Food.class))
        {
        Food food = new Food();
        
        removeTouching(Food.class);
        foodEaten++;
        SnakeWorld world = (SnakeWorld)getWorld();
        world.addFood();
        world.score.add(1);
        }
        
        if(facingEdge())
        {
            Greenfoot.stop();
        }
    }
}